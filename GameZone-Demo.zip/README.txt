GameZone Demo

এটি একটি স্থির, মোবাইল-উপযোগী ডেমো ওয়েবসাইট।
ব্যবহার:
1. index.html ফাইলটি ব্রাউজারে খুলুন।
2. GitHub-এ repository তৈরি করুন।
3. Add file > Upload files থেকে index.html আপলোড করুন।
4. Settings > Pages > Deploy from a branch নির্বাচন করুন।
5. Branch হিসেবে main এবং folder হিসেবে /(root) নির্বাচন করে Save চাপুন।

নোট: ভার্চুয়াল কয়েন ছাড়া বাস্তব টাকা, বাজি, ডিপোজিট বা উত্তোলনের ব্যবস্থা নেই।
